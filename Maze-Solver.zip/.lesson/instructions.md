# Introduction

Recursion can be an incredibly powerful technique for solving problems that require an unknown number of substeps. Determining when a problem cannot be solved through iteration is actually a very complex problem, but suffice to say that if you cannot create a traditional flowchart of an algorithm to solve a problem, then it cannot be solved without the use of some sort of stack. However, if you can repeatedly break a problem down into simpler versions of the same problem, then recursion is an option.

One great example is how to solve a two-dimensional maze. Consider a maze where you can only move up, down, left, or right, and then only if not blocked by a wall. You would have a difficult time trying to create an iterative algorithm that finds a solution. However, a recursive solution is quite elegant.

# Assignment

You will create a recursive method that will solve a maze contained within a two-dimensional array of char

## Requirements:

- Create a new project, and import the Point .java class 
- Import the MazeSolver.java class
- Implement the private boolean solveMaze(char[][] maze, Point current, Point end) method
  - the method should return true if the maze is solved, and false if it is not. Note that all mazes will be solveable, so it should never return false
  - the array should be modified to show the path as 'o' characters
  - clean up any other markings that you make in the array