class Main {
  public static void main(String[] args) {
    //Write your code in MazeSolver.java.
    MazeSolver.main(args);
    //No tests for this one, does it solve the maze properly?
  }
}